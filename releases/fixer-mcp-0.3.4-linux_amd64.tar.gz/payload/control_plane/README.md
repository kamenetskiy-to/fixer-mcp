# fixerctl — the single operator entry (Track б)

One Go + Bubble Tea binary that hosts the operator's daily utilities in a
keyboard-first menu instead of a pile of shell aliases. This is the first
runnable slice of program doc `fleet-consolidation-program` item 2 and backlog
`168`.

```
fixerctl  one entry for the operator's daily utilities  v0.1.0
platform: darwin · config: ~/.config/fixer/control-plane.json · vpn.env: absent · 8/9 runnable

▸ ✓ check-my-limits   AI provider quota table   /Users/…/.local/bin/cml
  ✓ my IP / VPN exit  public egress address     /Users/…/.local/bin/myip
  ✗ ai-pro            AI provider switcher      missing: ai-pro
  ✓ VPN up            launchd                   /Users/…/.local/bin/vpn-up
```

The alias layer is what keeps breaking: a macOS-only wrapper copied to Linux
died with exit 127, and stale aliases on the MacBook Air shadowed the managed
commands and broke `fixer`, `cml` and `codex-switch`. fixerctl resolves every
entry at startup and renders a missing binary as a disabled row with a reason
instead of failing at press time.

## Build and run

Go 1.25+ (the reference Mac has the 1.25 toolchain).

From the repository root:

```sh
make fixerctl           # builds control_plane/fixerctl for the host platform
./control_plane/fixerctl
```

To run test suites including control_plane:

```sh
make test-control-plane # runs Go tests in control_plane
make test-all           # runs all release, installer, install, and control-plane tests
```

Or directly from `control_plane/`:

```sh
cd control_plane
go build ./...
go test ./...
go build -o ./fixerctl ./cmd/fixerctl
./fixerctl
```

The module is self-contained (`github.com/kamenetskiy-to/fixer-mcp/control-plane`)
with its own `go.mod`; it does not share the `fixer_mcp` module.

Useful flags:

| Flag | Meaning |
| --- | --- |
| `-print` | print the resolved menu and exit (no TTY needed) |
| `-json` | with `-print`, emit JSON instead of a table |
| `-run ID` | run one entry by id with a PTY and exit (no menu) |
| `-config PATH` | use a different config file |
| `-repo PATH` | fixer-mcp checkout root for `fleet check` |
| `-version` | print `fixerctl vX.Y.Z (os/arch)` |

`fixerctl -print` is the automation surface: it is how the resolved menu and
every disabled reason can be asserted without opening a terminal. `fixerctl -run
ID` is the same PTY executor the menu uses, without the menu: useful for scripts
and for capturing a child's real output deterministically. It refuses disabled
entries with exit code 2 and propagates the child's exit code.

## Entries

| ID | Title | Default command | Platform |
| --- | --- | --- | --- |
| `cml` | check-my-limits | `cml` | all |
| `myip` | my IP / VPN exit | `myip` | all |
| `ssh-tui` | ssh-tui | `ssh-tui` | all |
| `ai-pro` | ai-pro | `ai-pro` | all |
| `vpn-up` | VPN up | `vpn-up` | darwin = launchd, linux/WSL = ssh-tunnel |
| `vpn-down` | VPN down | `vpn-down` | darwin = launchd, linux/WSL = ssh-tunnel |
| `codex-switch` | codex-switch | `codex-switch` | all |
| `fixer` | Fixer TUI | `fixer` | all |
| `fleet-check` | fleet check | `python3 <repo>/scripts/fleet/operator_env.py check` | all, needs a checkout |

Everything is resolved through `PATH` first. `fleet check` additionally needs a
fixer-mcp checkout: the root is discovered by walking up from the working
directory until `scripts/fleet/operator_env.py` is found, or pinned with
`repo_root` / `-repo`.

## Execution model (why a PTY)

Selecting an entry suspends the menu, hands the real terminal to the child under
a PTY, streams its output live, and returns to the menu when the child exits.
A PTY is required, not cosmetic: `fixer`, `ai-pro` and `ssh-tui` are curses
TUIs and will not render without a terminal. Because the child owns the screen
while it runs, full-screen apps behave exactly as they do in a shell.

Three details ride along with the PTY:

* the PTY is sized to the menu window and follows `SIGWINCH` resizes;
* the last few KiB of child output are captured, sanitized (ANSI stripped) and
  shown as a one-line `last: …` summary after the menu comes back;
* terminal input is forwarded with a poll loop that stops the moment the child
  exits, so the menu never loses the first keystroke after a run.

### VPN / proxy lane

When `${XDG_CONFIG_HOME:-$HOME/.config}/fleet/vpn.env` exists, the operator
tunnel is considered up. fixerctl sources that file into every child process
(its values win over the parent environment) and shows the marker state in the
header. This matches `client_wires/launch_env.py` and the
`provider-launch-env-wsl-vpn-lane` canon: without it, a CLI whose only route is
the operator proxy fails with a geo error that looks like a provider outage.
`FLEET_VPN_ENV_FILE` overrides the marker path; `vpn_env_file` does the same per
config.

## Config

Default path: `${XDG_CONFIG_HOME:-$HOME/.config}/fixer/control-plane.json`.
**A missing config is not an error** — the defaults above come from `PATH`. A
malformed config is reported in the menu and fixerctl keeps running with the
defaults.

```json
{
  "path_overrides": {
    "cml": "/opt/homebrew/bin/cml"
  },
  "order": ["fixer", "cml", "vpn-up", "vpn-down"],
  "vpn_env_file": "/Users/you/.config/fleet/vpn.env",
  "repo_root": "/Users/you/Desktop/projects/self_orchestration",
  "extra_entries": [
    {
      "id": "notes",
      "title": "Notes",
      "help": "quick scratchpad",
      "command": "notes",
      "args": ["--fast"]
    }
  ]
}
```

| Key | Effect |
| --- | --- |
| `path_overrides` | per-entry path or command name; `~` expands to `$HOME` |
| `extra_entries` | new entries; an entry whose `id` matches a built-in overrides it (non-empty fields win) |
| `order` | entry IDs shown first, in that order; unlisted IDs keep their default relative order |
| `vpn_env_file` | override the VPN marker path |
| `repo_root` | checkout used by `fleet check` |

### How to add an entry

1. Append an object to `extra_entries` with a unique `id`, a `title`, and the
   `command` to resolve through `PATH` (or an absolute path).
2. Optional fields: `help`, `args`, `platforms` (for example `["linux"]`) and
   `lane_by_platform` (for example `{"darwin": "launchd", "linux": "ssh-tunnel"}`).
3. Press `r` in the menu (or restart fixerctl). The new row appears with its
   resolved path, or as a disabled row explaining why it cannot run.
4. To replace a built-in entry instead, reuse its `id`.

## Disabled-entry rules

An entry is disabled — never a press-time crash — when:

| Rule | Rendered reason |
| --- | --- |
| The command is not on `PATH` | `missing: cml` |
| A `path_overrides` path does not exist | `missing: /opt/gone/cml` |
| The override exists but is not executable | `not executable: /opt/bin/cml` |
| `platforms` excludes this OS | `unsupported platform: darwin` |
| The VPN lane map has no lane for this OS | `unsupported platform: windows (lanes: darwin=launchd, linux=ssh-tunnel)` |
| `fleet check` has no checkout | `missing: scripts/fleet/operator_env.py` |
| `fleet check` has no `python3` | `missing: python3` |

Disabled entries are visible (with the reason) but the cursor skips them.

## Keys

| Key | Action |
| --- | --- |
| `↑`/`k`, `↓`/`j` | move between runnable entries |
| `g`/`G` | first / last runnable entry |
| `enter` | run the selected entry |
| `r` | re-resolve everything (PATH, config, VPN marker) |
| `?` | config and lane help |
| `q` / `ctrl+c` | quit |

## Tests

All tests are hermetic: resolution uses injected `LookPath`/`Stat` fakes, the
VPN parser reads temp files, and the Bubble Tea model tests inject a fake
`ExecCommand`. No test needs a real TTY, a real `PATH` or a real checkout.

```sh
go test ./...
```

Coverage by package:

* `internal/registry` — table-driven present/missing/disabled-with-reason,
  platform and lane gating, path overrides, extra entries, ordering, repo-root
  discovery.
* `internal/config` — missing/empty/malformed/valid config, XDG and HOME fallback.
* `internal/vpnenv` — marker path resolution, shell assignment parsing, env merge.
* `internal/runner` — ring buffer, ANSI stripping, env sourcing, real PTY
  round-trip (`sh -c 'printf …'`), exit-code propagation, and a regression test
  that no leftover input pump consumes a keystroke after the child exits.
* `internal/ui` — navigation that skips disabled rows, disabled entries not
  selectable, quit keys, enter wiring, reload, view rendering.

## Non-goals (this slice)

* No provider launching, no MCP client, no session management. That seam stays
  in Fixer MCP (later `terminal_control_client`); Track б never launches a
  provider itself.
* No changes outside `control_plane/` (beyond release packaging integration and Makefile target) — `client_wires/`, `installer/` and
  `scripts/fleet/` are untouched.
* Packaging into release payload is landed via `scripts/release/assemble_release.py` and `packaging/assembler.py`.

## Smallest next slices

1. **MCP control calls** — expose the menu as a Fixer MCP-backed surface so a
   Fixer can offer the same actions without a TTY.
2. **Alias migration** — run the existing `cml`/`codex-switch` wrappers through
   fixerctl and retire the home-relative stubs.
3. **Fleet environment integration** — wire `fixerctl` into `scripts/fleet/operator_env.py`
   so one install and verify step manages aliases and PATH across Mac, Ubuntu and WSL.
