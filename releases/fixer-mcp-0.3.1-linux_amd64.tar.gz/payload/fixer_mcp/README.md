# Work Boundary

All new public-repo and migration work is now performed only inside `github_repo/`.

Everything outside `github_repo/` stays as-is so the current Fixer MCP can remain usable while the new GitHub-ready version is designed, migrated, and validated.

Operational rule:
- do not refactor the legacy workspace in place
- do not treat the current repo root as the new publication target
- do architecture, migration planning, implementation, and packaging work only in `github_repo/`

The goal is to build a clean, backward-compatible GitHub version in parallel without breaking the current local system.

## Clean Install Smoke

The live workspace also carries a repo-native Docker harness for isolated reinstall checks:

```bash
make docker-smoke
```

The default smoke is non-interactive and does not require Codex auth. Optional auth-mounted and cleanup paths are documented in [`docs/docker-smoke.md`](docs/docker-smoke.md).

For the real Codex-backed bootstrap gate:

```bash
make docker-bootstrap-e2e
```

Fixer MCP's headless launcher uses the vendored `client_wires.codex_compat`
package, so no sibling `mcp_servers/codex_pro_app` checkout is required. The
bootstrap harness still mounts Codex auth read-only at runtime.

## Install And Update (Canonical Path)

There is exactly one supported install/update path: the managed portable
installer (`installer/`, `bin/fixer`, `scripts/install/`). It is the only path
that is documented for operators and the only path that self-updates.

```bash
# Install or update from this checkout (assembles a release, then installs it)
make install

# Verify the managed installation
make install-verify      # thin wrapper over: fixer doctor

# Update an existing managed installation from a published release descriptor
fixer update --check
fixer update
```

Defaults, all overridable:

| Variable | Default | Meaning |
| --- | --- | --- |
| `MANAGED_ROOT` | `$HOME/.fixer` | versioned releases live in `<root>/releases/<version>` behind an atomic `current` symlink |
| `MANAGED_STATE_DIR` | `$XDG_STATE_HOME/fixer-client-wires` | user state outside the release tree; an explicit `FIXER_DB_PATH` always wins |
| `USER_BIN_DIR` | `$HOME/.local/bin` | where the `fixer` command shim is installed |
| `RELEASE_VERSION` | `0.1.0` | version stamped into the assembled release descriptor |

`make install` never edits shell rc files. Run the installer directly with
`--add-to-path` if you want an idempotent, narrowly-marked PATH block:

```bash
python3 scripts/install/install.py --descriptor dist/release/release.json --add-to-path
```

Properties of the managed path:

- one atomic stage/apply engine for both fresh install and update
  (`installer.engine.InstallEngine`);
- previous releases are preserved on disk, so `rollback_to_previous()` works;
- an install lock prevents concurrent installers;
- activation is deferred (not lost) while an active Fixer runtime is detected
  against the shared state directory;
- the candidate binary is bootstrapped against a temporary SQLite database
  before `current` is switched;
- release payloads are allowlisted, SHA-256 verified, and extracted with
  traversal/symlink-escape checks.

### Legacy Development Bootstrap (Deprecated)

`scripts/install.sh` and `scripts/verify-install.sh` remain as the in-tree
development bootstrap. They build `fixer_mcp/fixer_mcp`, bootstrap
`fixer_mcp/fixer.db`, and are what the local MCP config and the Docker gates
consume. They are **not** the operator install path and are no longer reachable
through `make install` / `make install-verify`; use:

```bash
make dev-install
make dev-verify
```

`make verify-install` is kept as a deprecated alias that forwards to
`make install-verify` with a notice.

## Publication (One Flow)

Publication is one flow and it ends in `git@github.com:kamenetskiy-to/fixer-mcp.git`:

```bash
private tree
  -> make public-export            # scripts/prepare_public_repo.py
  -> dist/fixer-mcp-public/        # filtered + leak-scanned export
  -> github_repo/                  # nested clone, origin = public repo
  -> git push origin main          # operator-run, never automated here
```

```bash
make publish-dry-run     # export + rsync preview against github_repo (writes nothing, pushes nothing)
make publish             # export + rsync into github_repo + commit; prints the push command
```

Neither target pushes to a remote. The final command is always:

```bash
git -C github_repo push origin main
```

The export ships the managed install surface itself — `installer/`,
`packaging/` (including the vendored `tomli`), `bin/fixer`, `scripts/install/`,
and `scripts/release/` — with its executable bits intact. A published checkout
can therefore build a release from itself (`make install` /
`make install-verify`), and the installation it creates records that release
source, so it can check for and apply its own updates. The exporter fails the
export when any part of that surface is missing or no longer executable.

`packaging/assembler.py` is **not** a publication path. It produces the
immutable macOS release artifact (`fixer-mcp-<version>-darwin_<arch>.tar.gz`
plus a `format=1` `release.json` descriptor) that the managed installer and
`fixer update` consume. Source publication and binary release artifacts are two
different outputs of one build, which is why `make install` uses the assembler
and `make public-export` does not.

```bash
make assemble-release                                   # -> dist/release/
make verify-release                                     # archive + descriptor + extraction checks
```

## Test Suites

```bash
make test-installer   # unit tests: paths, metadata, lock, shim, fetcher, doctor, update cache
make test-install     # end-to-end install/update/fault-injection/blackbox tests
make test-release     # release assembly, allowlist, archive security, no-personal-paths tests
make test-all
```

All suites are Python 3.11+ `unittest` and run from the repository root with an
isolated temporary prefix; nothing is installed into `$HOME` by the tests.
The same suites are collectable by pytest:

```bash
pytest tests/install tests/installer tests/release
```

`tests/__init__.py` exists so that `tests/installer` cannot shadow the
top-level `installer` package: without it, pytest prepends `tests/` to
`sys.path` and `import installer.doctor` resolves to the test directory.
`python -m unittest discover -s tests` therefore needs `-t .`
(`python -m unittest discover -s tests -t .`) in this tree.
